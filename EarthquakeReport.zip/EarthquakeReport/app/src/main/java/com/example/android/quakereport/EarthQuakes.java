package com.example.android.quakereport;

/**
 * Created by SIR P on 9/11/2017.
 */

public class EarthQuakes {
    //declare the magnitude of the earthquake
    private double mMagnitude;
    //declare the location of the earthquake
    private String mLocation;
    //declare the date of the earthquake
    private String mDate;
    //declare the detail variable
    private String detail_url;

    //Create a constructor for the class with the parameters
    public EarthQuakes(double magnitude, String location, String date, String url){
        mMagnitude = magnitude;
        mLocation = location;
        mDate = date;
        detail_url = url;
    }

    //get the magnitude of the earthquake
    public double getMagnitude(){return mMagnitude;}
    //get the Location of the eartquake
    public String getLocation(){return mLocation;}
    //get the date of the earthquake
    public String getDate(){return mDate;}
    //get the detail url
    public String getDetailsUrl(){return detail_url;}
}
