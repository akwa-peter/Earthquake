package com.example.android.quakereport;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.List;

/**
 * Created by SIR P on 9/11/2017.
 */

public class EarthquakeAdapter extends ArrayAdapter<EarthQuakes> {

    public EarthquakeAdapter(Context context, List<EarthQuakes> earthquakes){
        super(context, 0, earthquakes);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        //check if there is an existing list item view (called convert view) that we can reuse
        //otherwise if convertView is null, then inflate a new item view
        View listItemView = convertView;
        if(convertView == null){
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.earthquake_list_item, parent, false);
        }

        //find the earthquake at a given position in the list of earthquakes
        EarthQuakes currentEarthquake = getItem(position);

        //find the magnitude TextView and set the magnitude value on it
        TextView magnitudeView = (TextView) listItemView.findViewById(R.id.txt_magnitude);
        //define a date format object
        DecimalFormat formatter = new DecimalFormat("0.00");
        String outPut = formatter.format(currentEarthquake.getMagnitude());
        magnitudeView.setText(outPut);

        //find the background of the magnitude Circle
        GradientDrawable magnitudeCircle = (GradientDrawable) magnitudeView.getBackground();
        //get the appropriate color for the magnitude
        int magnitudeColor = getMagnitudeColor(currentEarthquake.getMagnitude());
        //set the color on the magnitude background
        magnitudeCircle.setColor(magnitudeColor);

        //find the Location_offset TextView
        TextView location_offset = (TextView) listItemView.findViewById(R.id.location_offset);
        //find the primary location Textview
        TextView primary_location = (TextView) listItemView.findViewById(R.id.primary_location);

        //get the current location of the earthquake
        String location = currentEarthquake.getLocation();
        //check if the location string contains the string "of"
        if(location.contains("of")) {
            //split the location into two
            String[] locationArray = location.split("of ");

            //set the location offset value
            location_offset.setText(locationArray[0] + " of");
            //set the primary location value
            primary_location.setText(locationArray[1]);
        }
        else {
            location_offset.setText("Near the");
            primary_location.setText(location);
        }

        //find the date TextView and set the value on it
        TextView dateView = (TextView) listItemView.findViewById(R.id.txt_date);
        dateView.setText(currentEarthquake.getDate());

        return listItemView;
    }

    public int getMagnitudeColor(double magnitude){
        int color = 0;

        if(magnitude <= 2){
            color = R.color.magnitude1;
        }else if(magnitude > 2 && magnitude <= 3){
            color = R.color.magnitude2;
        }else if(magnitude > 3 && magnitude <= 4){
            color = R.color.magnitude3;
        }else if(magnitude > 4 && magnitude <= 5){
            color = R.color.magnitude4;
        }else if(magnitude > 5 && magnitude <= 6){
            color = R.color.magnitude5;
        }else if(magnitude > 6 && magnitude <= 7){
            color = R.color.magnitude6;
        }else if(magnitude > 7 && magnitude <= 8){
            color = R.color.magnitude7;
        }else if(magnitude > 8 && magnitude <= 9){
            color = R.color.magnitude8;
        }else if(magnitude > 9 && magnitude <= 10){
            color = R.color.magnitude9;
        }else {
            color = R.color.magnitude10plus;
        }
        return color;
    }
}
